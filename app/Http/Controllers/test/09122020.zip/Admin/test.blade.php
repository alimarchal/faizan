<div class="row">
    <div class="col-md-12">
        <ul class="timeline">
            <li class="event"><input type="radio" name="tl-group" checked="checked" /> <label></label>
                <div class="thumb khalid"><span>2017</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Dr. Khalid Rafique<span>14th April 2017 - Till now</span></h3>
                            <p>Joined Information Technology Board Azad Jammu &amp; Kashmir on 14th of December, 2017. Under his leadership IT Board has successfully completed many mega projects bringing the public and the government on the page of successfull e-governance and skilled kashmir. Among his accomplished milestones and success stories are "Automation of Land Record in AJ&amp;K", "Automation of Issuance of Computerized Driving License", "Automation of Judicial System of Supreme Court and High Court" and "Video Conferencing Solution in AJ&amp;K and Kashmir House Islamabad".</p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb mansoor"><span>2016</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Mansoor Qadir Dar<span>30th November 2016 - 13th April 2017</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb zahoor"><span>2016</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Zahoor ul Hassan Gillani<span>5th September 2016 - 29th November 2016</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb gondal"><span>2010</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Muhammad Sarwar Gondal<span>12th August 2010 - 12th August 2016</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb fayyaz"><span>2010</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Fayyaz Ali Abbasi<span>20th April 2010 - 12th August 2010</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb gondal"><span>2007</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Muhammad Sarwar Gondal<span>20th April 2007 - 20th April 2010</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb noImg"><span>2006</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Khurshid Ahmad Chaudhry<span>5th September 2006 - 19th April 2007</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb noImg"><span>2005</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Sardar Javaid Ayub<span>19th May 2005 - 4th September 2006</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb naeem"><span>2004</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Sardar Naeem Ahmad Sheeraz<span>7th December 2004 - 18th May 2005</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb noImg"><span>2004</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Khurshid Ahmad Chaudhry<span>28th September 2004 - 6th December 2004</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb saleem"><span>2004</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Muhammad Saleem Bismal<span>18th June 2004 - 27th September 2004</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="event"><input type="radio" name="tl-group" /> <label></label>
                <div class="thumb noImg"><span>2003</span></div>
                <div class="content-perspective">
                    <div class="content">
                        <div class="content-inner">
                            <h3>Mr. Moin Sadiq Malik<span>7th Fabruary 2003 - 7th May 2004</span></h3>
                            <p></p>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
